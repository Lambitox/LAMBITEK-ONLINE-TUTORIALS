const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());

// Example route: Contact form
app.post("/api/contact", (req, res) => {
  const { name, email, message } = req.body;
  console.log("New contact:", { name, email, message });

  // TODO: Send email via nodemailer or save to DB
  res.status(200).json({ success: true, msg: "Message received!" });
});

// Serve frontend (optional if deploying fullstack on one server)
const path = require("path");
app.use(express.static(path.join(__dirname, "../frontend/public")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/public/index.html"));
});

app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
