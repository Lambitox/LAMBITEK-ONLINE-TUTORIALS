# LAMBITEK Online Academy - Fullstack

## Setup

### Backend
```bash
cd backend
npm install
npm start
```

### Frontend
Static files are served automatically by Express from `frontend/public`.

## Deployment
- Can be deployed on Heroku, Render, or Railway.
- Frontend is bundled inside backend (served via Express).
